import{a as t}from"../chunks/entry.BK8VPGMr.js";export{t as start};
